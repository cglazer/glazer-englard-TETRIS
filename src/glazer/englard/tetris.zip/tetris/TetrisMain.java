package glazer.englard.tetris;

public class TetrisMain {
	public static void main(String[] args) {
		TetrisFrame frame = new TetrisFrame();
		frame.setVisible(true);
	}
}
