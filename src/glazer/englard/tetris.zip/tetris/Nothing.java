package glazer.englard.tetris;

public class Nothing {

}
