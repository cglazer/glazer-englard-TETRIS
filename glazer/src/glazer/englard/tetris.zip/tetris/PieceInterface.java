package glazer.englard.tetris;

public interface PieceInterface  {

	// void startPosition();
	void turn();
	//void moveRight();
	//void moveLeft();
	//void moveDown();
}
